/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gida-sil <gida-sil@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/08 09:54:39 by gida-sil          #+#    #+#             */
/*   Updated: 2025/05/08 11:12:52 by gida-sil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	p;

	i = 0;
	p = 0;
	while (dest[i] != '\0')
		i++;
	while (src[p] != '\0')
	{
		dest[i] = src[p];
		i++;
		p++;
	}
	dest[i] = '\0';
	return (dest);
}

// int	main(void)
// {
// 	char	f1[40] = "Oi ";
// 	char	f2[] = "avaliador\n";
// 	char *concat;

// 	concat = ft_strcat(f1, f2);
// 	printf("Resultado da concatenação: %s", concat);
// 	return (0);
// }