/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 05:30:24 by bchagas-          #+#    #+#             */
/*   Updated: 2025/05/08 14:02:47 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

void	ft_putnbr(int nb)
{
	long int	i;

	i = nb;
	if (i < 0)
	{
		ft_putchar('-');
		i = -i;
	}
	if (i < 10)
	{
		ft_putchar(i + '0');
	}
	else
	{
		ft_putnbr (i / 10);
		ft_putchar (i % 10 + '0');
	}
}
int	main()
{
	//-2147483648 a 2147483647
	ft_putnbr(42);
	return (0);
}
