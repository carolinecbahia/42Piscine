/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 19:17:18 by galves-c          #+#    #+#             */
/*   Updated: 2025/05/03 16:40:16 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > 96 && str[i] < 123)
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int	main(void)
{
	printf("teste com letras min apenas: %d\n", ft_str_is_lowercase("abc"));
	printf("teste com letras maiusculas: %d\n", ft_str_is_lowercase("abC"));
	printf("teste com numeros: %d\n", ft_str_is_lowercase("123"));
	printf("teste com nada: %d\n", ft_str_is_lowercase(""));
}
