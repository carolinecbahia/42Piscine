/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 20:36:27 by galves-c          #+#    #+#             */
/*   Updated: 2025/05/03 16:42:30 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > 31 && str[i] < 127)
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int	main(void)
{
	printf("teste com printaveis: %d\n", ft_str_is_printable("abc"));
	printf("teste com nao printavel: %d\n", ft_str_is_printable("abc\n"));
	printf("teste com nada: %d\n", ft_str_is_printable(""));
	return (0);
}
