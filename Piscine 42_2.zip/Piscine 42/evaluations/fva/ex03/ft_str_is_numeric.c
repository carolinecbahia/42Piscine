/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fvasconc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 15:41:24 by fvasconc          #+#    #+#             */
/*   Updated: 2025/05/03 15:41:39 by fvasconc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	ft_str_is_numeric(char *str)
{
	while (*str != '\0')
	{
		if (*str >= '0' && *str <= '9')
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*int main()
{
    char test[] = "12345";
    char test1[] = "Abc@#";
    char test2[] = "";
    printf("Numérico = %d\n", ft_str_is_numeric(test));
    printf("Outro Tipo = %d\n", ft_str_is_numeric(test1));
    printf("Vazio = %d\n", ft_str_is_numeric(test2));
    return(0);  
}*/
