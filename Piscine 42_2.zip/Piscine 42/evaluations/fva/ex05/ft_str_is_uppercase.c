/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fvasconc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 17:25:25 by fvasconc          #+#    #+#             */
/*   Updated: 2025/05/03 17:26:36 by fvasconc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	while (*str != '\0')
	{
		if (*str >= 65 && *str <= 90)
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*int main()
{
    char test[] = "ABC";
    char test1[] = "abcd@#";
    char test2[] = "";
    printf("Alfabético = %d\n", ft_str_is_uppercase(test));
    printf("Outro Tipo = %d\n", ft_str_is_uppercase(test1));
    printf("Vazio = %d\n", ft_str_is_uppercase(test2));
    return(0);  
}*/
