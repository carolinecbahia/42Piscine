/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fvasconc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 17:15:23 by fvasconc          #+#    #+#             */
/*   Updated: 2025/05/03 17:16:23 by fvasconc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	ft_str_is_lowercase(char *str)
{
	while (*str != '\0')
	{
		if (*str >= 97 && *str <= 122)
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*int main()
{
    char test[] = "abcd";
    char test1[] = "ABCd@#";
    char test2[] = "";
    printf("Alfabético = %d\n", ft_str_is_lowercase(test));
    printf("Outro Tipo = %d\n", ft_str_is_lowercase(test1));
    printf("Vazio = %d\n", ft_str_is_lowercase(test2));
    return(0);  
}*/
