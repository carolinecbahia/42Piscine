/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bsepulve <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 19:55:20 by bsepulve          #+#    #+#             */
/*   Updated: 2025/05/06 19:55:23 by bsepulve         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i ++;
	}
}
/*
int main(void)
{
    ft_putstr("Hello, world!\n");
    ft_putstr("Teste de escrita.\n");
    ft_putstr("\n");
    return 0;
}
*/
