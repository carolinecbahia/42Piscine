id -Gn $FT_USER | tr ' ' ','
