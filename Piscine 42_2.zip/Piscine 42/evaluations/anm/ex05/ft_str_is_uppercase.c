/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/25 15:14:56 by anmedeir          #+#    #+#             */
/*   Updated: 2025/04/27 14:43:42 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 'A' || str[i] > 'Z')
			return (0);
		i++;
	}
	return (1);
}

int	main(void)
{
	printf("%d\n", ft_str_is_uppercase("OLA"));   // 1
	printf("%d\n", ft_str_is_uppercase("OLA78")); // 0
	printf("%d\n", ft_str_is_uppercase(""));         // 1
	printf("%d\n", ft_str_is_uppercase("Ola"));    // 0
	return (0);
}
