#!/bin/bash

ifconfig | grep ether; echo
