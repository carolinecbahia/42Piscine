/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabalves <gabalves@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 18:28:59 by gabalves          #+#    #+#             */
/*   Updated: 2025/05/05 13:38:17 by gabalves         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	n;

	i = 0;
	n = 0;
	while (dest[i])
		i++;
	while (src[n])
	{
		dest[i] = src[n];
		i++;
		n++;
	}
	dest[i] = '\0';
	return (dest);
}
// int main()
//{
//	int i;
//	i = 10;
//	char s[] = "sadas";
//	char d[] = "teste";
//	ft_strcat(d, s);
//	write(1, d, i);
//	return (0);
//}
