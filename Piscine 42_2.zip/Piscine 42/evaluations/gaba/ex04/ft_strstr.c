/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabalves <gabalves@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 20:29:44 by gabalves          #+#    #+#             */
/*   Updated: 2025/05/05 13:42:06 by gabalves         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	n;
	int	x;

	x = 0;
	if (*to_find == '\0')
		return (str);
	while (str[x] != '\0')
	{
		n = 0;
		while (str[x + n] == to_find[n])
		{
			if (to_find[n + 1] == '\0')
				return (&str[x]);
			n++;
		}
		x++;
	}
	return (0);
}
//int	main(void)
//{
//	char	*result;
//	char	tf[] = "tes";
//	char	str[] = "tetes";
//
//	result = ft_strstr(str, tf);
//	// printf("%s",ft_strstr(str, tf));
//	write(1, result, 5);
//}
