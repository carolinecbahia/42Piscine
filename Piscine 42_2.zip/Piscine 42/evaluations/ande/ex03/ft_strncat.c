/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/28 18:21:43 by ande-and          #+#    #+#             */
/*   Updated: 2025/05/07 12:02:02 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	int				size;

	i = 0;
	size = 0;
	while (dest[size] != '\0')
	{
		size++;
	}
	while ((src[i] != '\0') && (i < nb))
	{
		dest[size + i] = src[i];
		i++;
	}
	return (dest);
}

#include <stdio.h>

int main(void)
{
	char src[] = "fonte";
	char dest[50] = "destino";

	ft_strncat(dest, src, 3);
	printf("%s %s", src, dest);
	return (0);
}