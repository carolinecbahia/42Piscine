/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 16:29:36 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 19:03:56 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	j;
	int	temp;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < size - 1)
		{
			if (tab[j] > tab[j + 1])
			{
		temp = tab[j];
		tab[j] = tab[j + 1];
		tab[j + 1] = temp;
			}
	j++;
		}
	i++;
	}
}

#include <stdio.h>
int main(void)
{
	int tab[5] ={-4789, 1, 35536, 25, -12};

	int size;

	size = 5;
	ft_sort_int_tab(tab, size);

	int i;

	i = 0;
	while(i < size)
	{
		printf("%d\n", tab[i]);
		i++;
	}
	return (0);

}
