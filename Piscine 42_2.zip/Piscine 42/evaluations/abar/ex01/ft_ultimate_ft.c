/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abarbeir <abarbeir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 16:08:46 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 15:32:59 by abarbeir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

// int	main(void)
// {
// 	int	x;
// 	int	*p1=&x;	
// 	int	**p2=&p1;
// 	int	***p3=&p2;
// 	int	****p4=&p3;
// 	int	*****p5=&p4;
// 	int	******p6=&p5;
// 	int	*******p7=&p6;
// 	int	********p8=&p7;
// 	int	*********p9=&p8;
// 	ft_ultimate_ft(p9);	
// 	char dezena;
// 	char unidade;
// 	dezena = (x / 10) + '0';
// 	unidade = (x % 10) + '0';
// 	write(1, &dezena, 1);
// 	write(1, &unidade, 1);
// 	write(1, "\n", 1);
// 	return (0);
// }
