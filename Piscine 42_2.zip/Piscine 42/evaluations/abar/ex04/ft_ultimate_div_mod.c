/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abarbeir <abarbeir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 10:46:30 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 15:37:39 by abarbeir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = temp / *b;
	*b = temp % *b;
}

// int main(void)
// {
//     int a;
//     int b;
//
//     a = 8;
//     b = 3;
//
//     ft_ultimate_div_mod(&a, &b);
//
//     char c_a;
//     char c_b;
//
//     c_a = a + '0';
//     c_b = b + '0';
//
//     write(1, &c_a, 1);
//     write(1, &c_b, 1);
//     write(1, "\n", 1);
//     return 0;
// }