/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abarbeir <abarbeir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 18:04:26 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 15:35:51 by abarbeir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_div_mod(int a, int b, int*div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

// int main(void)
// {
// 	int a;
// 	int b;
// 	int div;
// 	int mod;
//
// 	a = 6;
// 	b = 9;
//
// 	ft_div_mod(a, b, &div, &mod);
//
// 	char c_div;
// 	char c_mod;
//
// 	c_div = div + '0';
// 	c_mod = mod + '0';
//
// 	write(1, &c_div, 1);
// 	write(1, &c_mod, 1);
// 	return 0;	
// }