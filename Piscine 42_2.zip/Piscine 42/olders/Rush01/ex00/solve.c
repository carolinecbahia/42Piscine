/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/27 13:06:53 by ccavalca          #+#    #+#             */
/*   Updated: 2025/04/27 20:05:04 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c);
int	check_column_up(int i, int j, int grid[4][4], int arr[4][4]);

/*agoritmo de backtracking

se col/row = 4, preencher sequencia 1234
se col/row = 1, preencher só 4 na primeira casa da direção de visão

visão sup e dir:
verificar col/row se número repetido, senão imprime
verificar se já atende a clue
se sim, prox col/row
se tudo preenchido, encerra solução
se não, repete

visão inf e esq:
verificar clue
/*/

int	check_column_up(int i, int j, int grid[4][4], int arr[4][4])
{
	int	k;
	int	l;
	int num;

	i = 0;
	k = 0;
	l = 0;
	num = 0;
	while (i < 4)
	{
		if (grid[k][l] == -1)
		{
			if (arr[i][j] == 4)
			{
				while (k < 4)
			{
						grid[k][j] = k + 1;
						ft_putchar(num + '1');
						k++;
						num++;
			}
			}
			else if (arr[i][j] == 1)
			{
				grid[0][l] = 4;
				ft_putchar('4');
				j++;
			}
		}
		i++;
	}
	return (0);
}
