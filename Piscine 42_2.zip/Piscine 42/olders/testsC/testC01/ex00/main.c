#include <stdio.h>

int main(void)
{
    int x;

    ft_ft(&x);
    printf("%d\n", x);
    return (0);
}
