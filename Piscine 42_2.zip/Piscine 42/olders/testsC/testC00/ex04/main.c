void	ft_is_negative(int n);

int main()
{
	ft_is_negative(10);
	ft_is_negative(-8);
	
	return(0);
}
