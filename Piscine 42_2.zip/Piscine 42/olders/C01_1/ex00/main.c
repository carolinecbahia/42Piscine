#include <stdio.h>

void ft_ft(int *nbr);

int	main(void)
{
	int x;

	ft_ft(&x);
	printf("%d\n", x);
	return (0);
}
