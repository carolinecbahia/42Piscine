/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 17:48:36 by ccavalca          #+#    #+#             */
/*   Updated: 2025/04/29 18:48:13 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_printable(char *str);

int	ft_is_printable(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		if (! (str[i] >= 32 && str[i] <= 127))
			return (0);
		i++;
	}
	return (1);
}

#include <stdio.h>

int main(void)
{
	printf("%d\n", ft_is_printable("ABCDEF"));
	printf("%d\n", ft_is_printable("abcd1234"));
	printf("%d\n", ft_is_printable("teste"));
	printf("%d\n", ft_is_printable(""));
	return (0);
}