/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 16:03:17 by ccavalca          #+#    #+#             */
/*   Updated: 2025/05/01 16:10:52 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str);

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 1;
	while (str[i] != '\0')
	{
		if (str[0] >= 'a' && str[0] <= 'z')
			str[0] = str[0] - 32;
		else if (((str[i] >= 'a' && str[i] <= 'z')
				&& (str[i - 1] == ' ' || str[i -1] <= 47)))
			str[i] = str[i] - 32;
		else if ((str[i] >= 'A' && str[i] <= 'Z') && str[i - 1] != ' ')
			str[i] = str[i] + 32;
		i++;
	}
	return (str);
}

// #include <stdio.h>

// int main(void)
// {
// 	char str1[] = "oi, tudo bem? 42palavras quarenta-e-duas; cinquenta+e+um";
// 	char str2[] = "Frase De Efeito Aqui";
// 	char str3[] = "FRASE de EFEITO aqui";

// 	printf("%s\n", ft_strcapitalize(str1));
// 	printf("%s\n", ft_strcapitalize(str2));
// 	printf("%s\n", ft_strcapitalize(str3));
// 	return (0);
// }