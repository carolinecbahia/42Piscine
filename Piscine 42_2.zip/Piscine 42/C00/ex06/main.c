void	ft_print_comb2(void);

int	main(void)
{
	ft_print_comb2();
	return (0);
}