/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/07 16:00:10 by ccavalca          #+#    #+#             */
/*   Updated: 2025/05/08 15:01:22 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb);

int	ft_is_prime(int nb)
{
	int	i;

	if (nb <= 1)
		return (0);
	if (nb <= 3 && nb != 1)
		return (1);
	if (nb % 2 == 0 || nb % 3 == 0)
		return (0);
	i = 5;
	while ((i * i) <= nb)
	{
		if (nb % i == 0 || nb % (i + 2) == 0)
			return (0);
	}
	return (1);
}

// #include <stdio.h>

// int main(void)
// {
// int numero = 10;
// 	if (ft_is_prime(numero)) 
// 	{
// 		printf("%d é um número primo.\n", numero);
// 	} 
// 	else 
// 	{
// 		printf("%d não é um número primo.\n", numero);
// 	}
// return 0;
// }