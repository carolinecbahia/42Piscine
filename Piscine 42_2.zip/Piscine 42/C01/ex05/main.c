void	ft_putstr(char *str);

int	main(void)
{
	ft_putstr("Hello world!");
	return (0);
}
