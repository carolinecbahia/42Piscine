void ft_putchar(char c);

int main ()
{
	char	letter = 'b';
	ft_putchar(letter);
	return (0);
}