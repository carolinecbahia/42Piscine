/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/27 13:06:47 by ccavalca          #+#    #+#             */
/*   Updated: 2025/04/27 20:02:42 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void ft_putchar(char c);
void ft_print_error(void);
int ft_verify_length(char *str);
int ft_verify_valid_string(char *str);
void check_column_up(int lin, int col, int grid[4][4], int arr[4][4]);

int	main(int argc, char *argv[])
{	
	int		idx;
	int		idx_str;
	int		col;
	int		lin;
	int	grid[4][4];
	int	arr[4][4];
	int	num;

	idx = 0;
	col = 0;
	lin = 0;
	idx_str = 0;
	if (argc != 2) 
	{
		ft_print_error();
		return (1);
	}
	if (argc == 2) 
	{
		if (ft_verify_length(argv[1]) != 31) {
			ft_print_error();
			return (1);
		}

		if	(!ft_verify_valid_string(argv[1]))
		{
			ft_print_error();
			return (1);
		}

		while (argv[1][idx_str] != '\0')
		{
			if (argv[1][idx_str] != ' ')
			{
				num = argv[1][idx_str] - '0';
				arr[lin][col] = num;
				col++;
				if (col == 4)
				{
					col = 0;
					lin++;
				}
			}
			idx_str++;
		}
		while (col < 4)
		{
			check_column_up(lin, col, grid, arr);
			col++;
		}
	}
	lin = 0;
	while (lin < 4)
	{
		col = 0;
		while (col < 4)
		{
			num = grid[lin][col];
			ft_putchar(num + '0');
			col++;
		}
		ft_putchar('\n');
		lin++;
	}

	return (0);
}
