/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   valid.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fsousa <fsousa@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/27 13:06:56 by ccavalca          #+#    #+#             */
/*   Updated: 2025/04/27 18:21:02 by fsousa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_verify_length(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_verify_number_range(char c)
{
	if (c >= '1' && c <= '4')
	{
		return (1);
	}
	return (0);
}

int	ft_verify_valid_string(char *str)
{
	int		idx;

	idx = 0;
	while (str[idx])
	{
		if (!ft_verify_number_range(str[idx]) && str[idx] != ' ')
		{
			return (0);
		}
		idx++;
	}
	return (1);
}
