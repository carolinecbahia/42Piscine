/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   grid.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/27 13:06:44 by ccavalca          #+#    #+#             */
/*   Updated: 2025/04/27 20:01:18 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

/*criar matriz 4x4 para receber os números
sem imprimir
função para encerrar a matriz depois do uso*/

int	grid_init(int m, int n)
{
	int	**matriz;
		int	i;

	i = 0;
	matriz = (int **) malloc (sizeof (int *) * n);
	if (matriz == NULL)
	{
		write(1, "Error", 5);
		exit(1);
	}
	while (i < m)
	{
	i++;
		if (matriz[i] == NULL)
			write(1, "Error", 5);
		exit(1);
	}
	return (0);
}

void	grid_end(int **matriz, int m)
{
	int	i;

	i = 0;
	while (i < m)
	{
		free (matriz[i]);
		free(matriz);
		i++;
	}
}
