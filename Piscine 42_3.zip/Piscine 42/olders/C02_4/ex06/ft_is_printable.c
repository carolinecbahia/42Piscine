/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_printable.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 15:19:22 by ccavalca          #+#    #+#             */
/*   Updated: 2025/05/03 16:30:38 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_printable(char *str);

int	ft_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] <= 31)
		{
			return (0);
		}
		i++;
	}
	return (1);
}

// #include <stdio.h>

// int main(void)
// {
// 	printf("%d\n", ft_is_printable("ABCDEF"));
// 	printf("%d\n", ft_is_printable("abcd1234"));
// 	printf("%d\n", ft_is_printable("test\ne"));
// 	printf("%d\n", ft_is_printable(""));
// 	return (0);
// }