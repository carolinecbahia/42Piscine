/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fabialme <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/02 17:43:40 by fabialme          #+#    #+#             */
/*   Updated: 2025/05/02 17:43:44 by fabialme         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

void ft_putstr(char *str);


int	main(int ac, char **av)
{
	(void)ac;
	(void)av;
	int fd;
	char buffer[1024];
	ssize_t bytesRead;
	
	fd = open("numbers.dict", O_RDONLY);
	if (fd == -1)
	{
		ft_putstr("Err ao abrir arquivo");
		return 1;
	}
	while ((bytesRead = read(fd, buffer, sizeof(buffer))) > 0)
		write(1, buffer, bytesRead);
	if(bytesRead == -1)
	{
		ft_putstr("Erro\n");
		close(fd);
		return (1);
	}
	close(fd);

	return (0);
}

