/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 17:26:21 by ccavalca          #+#    #+#             */
/*   Updated: 2025/05/06 18:53:57 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr_base(int nbr, char *base);
void	ft_putchar(char c);
int		valid_base(char *base);
int		ft_strlen(char *str);

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

int	valid_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-' || base[i] <= 32 || base[i] > 126)
			return (0);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
	i++;
	}
	return (i >= 2);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	base_len;

	if (!valid_base(base))
		return ;
	base_len = ft_strlen(base);
	if (nbr == -2147483648)
	{
		ft_putchar('-');
		ft_putnbr_base(nbr / base_len, base);
		ft_putchar(base[-(nbr % base_len)]);
		return ;
	}
	if (nbr < 0)
	{
		ft_putchar('-');
		nbr = -nbr;
	}
	if (nbr >= base_len)
		ft_putnbr_base(nbr / base_len, base);
	ft_putchar(base[nbr % base_len]);
}

// int main(void)
// {
// 	write(1, "Decimal: ", 9);
// 	ft_putnbr_base(-12345, "0123456789");
// 	write(1, "\n", 1);
// 	write(1, "Binário: ", 9);
// 	ft_putnbr_base(42, "01");
// 	write(1, "\n", 1);
// 	write(1, "Hexadecimal: ", 13);
// 	ft_putnbr_base(255, "0123456789ABCDEF");
// 	write(1, "\n", 1);
// 	write(1, "Base inválida: ", 15);
// 	ft_putnbr_base(42, "112345");
// 	write(1, "\n", 1);
// 	return (0);
// }