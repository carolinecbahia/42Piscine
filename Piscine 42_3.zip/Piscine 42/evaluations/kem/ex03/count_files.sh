#!/bin/bash

find \( -type f -o -type d \) -print | wc -l 
