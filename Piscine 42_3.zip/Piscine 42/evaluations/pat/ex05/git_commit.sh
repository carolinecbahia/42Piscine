git log --pretty=tformat:"%H" -5
