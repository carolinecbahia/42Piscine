/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/30 10:45:51 by apanambi          #+#    #+#             */
/*   Updated: 2025/05/05 17:33:35 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

int	main(void)
{
	int	a;
	int	*ponto1;
	int	**ponto2;
	int	***ponto3;
	int	****ponto4;
	int	*****ponto5;
	int	******ponto6;
	int	*******ponto7;
	int	********ponto8;
	int	*********ponto9;
	a = 24;
	ponto1 = &a;
	ponto2 = &ponto1;
	ponto3 = &ponto2;
	ponto4 = &ponto3;
	ponto5 = &ponto4;
	ponto6 = &ponto5;
	ponto7 = &ponto6;
	ponto8 = &ponto7;
	ponto9 = &ponto8;
	ft_ultimate_ft(ponto9);

	printf("Voce venceu na %d!!!\n", a);
	return (0);
}
