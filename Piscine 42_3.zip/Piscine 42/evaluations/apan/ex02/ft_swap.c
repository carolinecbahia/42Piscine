/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 14:44:52 by apanambi          #+#    #+#             */
/*   Updated: 2025/05/05 17:33:45 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_swap(int *a, int *b)
{
	int	inverso;

	inverso = *a;
	*a = *b;
	*b = inverso;
}

#include <stdio.h>
int	main(void)
{
	int	a;
	int	b;
	a = 2;
	b = 4;
	ft_swap (&a, &b);
	printf("O inverso aqui desse A deu %d\n", a); 
	printf("E o inverso de B deu %d\n", b);
	return (0);
}
