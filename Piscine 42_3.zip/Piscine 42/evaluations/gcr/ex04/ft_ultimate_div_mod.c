/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 14:34:49 by gcruz-pe          #+#    #+#             */
/*   Updated: 2025/04/24 14:42:12 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *a / *b;
	*b = c % *b;
}

int	main(void)
{
	int	x;
	int	y;
	x = 42;
	y = 10;
	ft_ultimate_div_mod(&x, &y);
	printf("A divisao de x/y é %d e o resto é %d\n", x, y);
}
