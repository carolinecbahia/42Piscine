/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str.is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 20:27:17 by galves-c          #+#    #+#             */
/*   Updated: 2025/05/03 16:42:07 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > 64 && str[i] < 91)
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int	main(void)
{
	printf("teste com apenas maiusc: %d\n", ft_str_is_uppercase("ABC"));
	printf("teste com minusc: %d\n", ft_str_is_uppercase("ABc"));
	printf("teste com numeros: %d\n", ft_str_is_uppercase("123"));
	printf("teste com nada: %d", ft_str_is_uppercase(""));
	return (0);
}
