/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 19:11:52 by galves-c          #+#    #+#             */
/*   Updated: 2025/05/03 16:39:22 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] > 47 && str[i] < 58)
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int	main(void)
{
	printf("teste com letras apenas: %d\n", ft_str_is_numeric("abc"));
	printf("teste com numeros: %d\n", ft_str_is_numeric("123"));
	printf("teste sem nada: %d\n", ft_str_is_numeric(""));
	return (0);
}
