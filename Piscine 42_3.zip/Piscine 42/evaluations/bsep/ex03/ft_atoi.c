/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bsepulve <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 19:55:46 by bsepulve          #+#    #+#             */
/*   Updated: 2025/05/07 18:24:31 by bsepulve         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	is_white_space(char c)
{
	return ((c >= 9 && c <= 13) || c == 32);
}

int	is_number(char c)
{
	return (c >= '0' && c <= '9');
}

void	parse_and_compute(char *str, int *i, int *final)
{
	int	digit;

	while (is_number(str[*i]))
	{
		digit = str[*i] - '0';
		*final = *final * 10 + digit;
		(*i)++;
	}
}

int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	final;

	i = 0;
	sign = 1;
	final = 0;
	while (is_white_space(str[i]))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	parse_and_compute(str, &i, &final);
	return (sign * final);
}

/*
int main(void)
{
    printf("%d\n", ft_atoi("   ---+--+1234ab567")); // -1234
    printf("%d\n", ft_atoi("   +42"));              // 42
    printf("%d\n", ft_atoi("   -00001abc"));         // -1
    printf("%d\n", ft_atoi("abc"));                 // 0
    printf("%d\n", ft_atoi("  \t\n\v\f\r  +00100")); // 100
    return 0;
}
*/
