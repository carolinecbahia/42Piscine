/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bsepulve <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 19:54:20 by bsepulve          #+#    #+#             */
/*   Updated: 2025/05/06 19:54:24 by bsepulve         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}
/*
int main(void)
{
    printf("Tamanho: %d\n", ft_strlen("Hello"));
    printf("Tamanho: %d\n", ft_strlen(""));
    printf("Tamanho: %d\n", ft_strlen("42 São Paulo"));
    return 0;
}
*/
