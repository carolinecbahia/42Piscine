/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bsepulve <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 19:55:31 by bsepulve          #+#    #+#             */
/*   Updated: 2025/05/06 19:55:34 by bsepulve         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	parse_digits(long *n, char *buff, int *i)
{
	while (*n > 0)
	{
		buff[(*i)++] = (*n % 10) + '0';
		*n /= 10;
	}
}

void	ft_putnbr(int nb)
{
	long	n;
	int		i;
	int		sign;
	char	buff[12];

	n = nb;
	i = 0;
	sign = 1;
	if (n == 0)
		return (write(1, "0", 1), (void)0);
	if (n < 0)
		sign = -1;
		n *= -1;
	parse_digits(&n, buff, &i);
	if (sign < 0)
		write(1, "-", 1);
	while (--i >= 0)
		write(1, &buff[i], 1);
}
/*
int main(void)
{
    ft_putnbr(42);
    write(1, "\n", 1);
    ft_putnbr(-12345);
    write(1, "\n", 1);
    ft_putnbr(0);
    write(1, "\n", 1);
    ft_putnbr(2147483647); // Maior valor de int
    write(1, "\n", 1);
    ft_putnbr(-2147483648); // Menor valor de int
    write(1, "\n", 1);
    return 0;
}
*/
