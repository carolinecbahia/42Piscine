/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fvasconc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 18:30:12 by fvasconc          #+#    #+#             */
/*   Updated: 2025/05/03 18:30:20 by fvasconc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	ft_str_is_printable(char *str)
{
	while (*str != '\0')
	{
		if (*str >= 32 && *str <= 126)
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*int main()
{
    char test[] = "#$%#";
    char test1[] = "\n";
    char test2[] = "";
    printf("caracteres imprimíveis = %d\n", ft_str_is_printable(test));
    printf("Outro Tipo = %d\n", ft_str_is_printable(test1));
    printf("Vazio = %d\n", ft_str_is_printable(test2));
    return(0);  
}*/
