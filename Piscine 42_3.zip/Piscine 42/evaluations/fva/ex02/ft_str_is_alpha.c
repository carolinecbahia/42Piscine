/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fvasconc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 15:14:39 by fvasconc          #+#    #+#             */
/*   Updated: 2025/05/03 15:32:39 by fvasconc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
int	ft_str_is_alpha(char *str)
{
	while (*str != '\0')
	{
		if ((*str >= 65 && *str <= 90) || (*str >= 97 && *str <= 122))
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*int main() {
    char test[] = "ABcd";
    char test1[] = "!#@";
    char test2[] = "";
    printf("Alfabéticos = %d\n", ft_str_is_alpha(test));
    printf("Outros tipos = %d\n", ft_str_is_alpha(test1));
    printf("vazio = %d\n", ft_str_is_alpha(test2));
    return 0;
}*/
