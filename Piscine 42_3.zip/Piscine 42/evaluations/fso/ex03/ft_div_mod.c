/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 11:07:03 by fsousa            #+#    #+#             */
/*   Updated: 2025/04/24 15:06:51 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

int	main(void)
{
	int	div;
	int	mod;
	int	x;
	int	y;

	x = 42;
	y = 10;
	ft_div_mod(x, y, &div, &mod);
	printf("A divisao de %d/%d = %d e o resto é %d\n", x, y, div, mod);
	return (0);
}
