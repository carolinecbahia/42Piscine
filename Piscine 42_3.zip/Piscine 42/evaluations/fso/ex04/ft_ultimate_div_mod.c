/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 11:47:33 by fsousa            #+#    #+#             */
/*   Updated: 2025/04/24 15:07:37 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b);

void	ft_ultimate_div_mod(int *a, int *b)
{
	int		temp;

	temp = *a;
	*a = temp / *b;
	*b = temp % *b;
}

int	main(void)
{
	int	x;
	int	y;
	x = 42;
	y = 10;
	ft_ultimate_div_mod(&x, &y);
	printf("A divisao de x/y é %d e o resto é %d\n", x, y);
}
