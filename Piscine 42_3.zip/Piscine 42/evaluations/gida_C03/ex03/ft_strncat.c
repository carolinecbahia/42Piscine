/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gida-sil <gida-sil@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/08 11:14:05 by gida-sil          #+#    #+#             */
/*   Updated: 2025/05/08 11:37:21 by gida-sil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	p;

	i = 0;
	p = 0;
	while (dest[i] != '\0')
		i++;
	while (p < nb && src[p] != '\0')
	{
		dest[i] = src[p];
		i++;
		p++;
	}
	dest[i] = '\0';
	return (dest);
}

// int	main(void)
// {
// 	char	f1[40] = "Bom ";
// 	char	f2[] = "dia";
// 	unsigned int limite = 1;

// 	ft_strncat(f1, f2, limite);
// 	printf("Resultado da delimitação: %s", f1);
// 	return (0);
// }