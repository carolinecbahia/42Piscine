/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/08 11:41:46 by gida-sil          #+#    #+#             */
/*   Updated: 2025/05/08 14:19:11 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	p;

	i = 0;
	if (!*to_find)
		return (str);
	while (str[i] != '\0')
	{
		p = 0;
		while (str[i + p] == to_find[p] && to_find[p] != '\0')
			p++;
		if (to_find[p] == '\0')
			return (&str[i]);
		i++;
	}
	return (NULL);
}

int main(void)
{
	char	frase[] = "Eu estou estudando muito";
	char	palavra[] = "estu";
	char	*resultado;

	resultado = ft_strstr(frase, palavra);
	printf("Resultado: %s", resultado);
	return (0);
}