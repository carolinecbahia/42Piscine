/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/02 14:36:30 by rafaoliv          #+#    #+#             */
/*   Updated: 2025/05/07 14:09:09 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_negnbr(int nbr)
{
	if (nbr < 0)
	{
		nbr *= -1;
		write(1, "-", 1);
	}
	return (nbr);
}

long int	ft_max_int(int nbr)
{
	long int	maxint;

	maxint = nbr;
	maxint *= -1;
	return (maxint);
}

int	ft_base_length(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
	{
		i++;
	}
	return (i);
}

int	ft_base_validation(char *base)
{
	int	i;
	int	j;
	int	baselength;

	baselength = ft_base_length(base);
	i = 0;
	if (baselength <= 1)
		return (0);
	while (base[i] != '\0')
	{
		j = i + 1;
		if (base[i] == '-' || base[i] == '+' || base[i] == 32)
			return (0);
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{	
	int			baselength;
	long int	maxint;

	baselength = ft_base_length(base);
	if (ft_base_validation(base) == 0)
		return ;
	if (nbr == -2147483648)
	{
		write(1, "-", 1);
		maxint = ft_max_int(nbr);
		ft_putnbr_base(maxint / baselength, base);
		write(1, &base[maxint % baselength], 1);
		return ;
	}
	if (nbr < 0)
		nbr = ft_negnbr(nbr);
	if (nbr > 0)
	{		
		ft_putnbr_base(nbr / baselength, base);
		write(1, &base[nbr % baselength], 1);
	}
}

int	main(void)
{
	int	nbr;
	char	*base;

	nbr = -2147483648;
	base = "0123456789";
	ft_putnbr_base(nbr, base);
}
