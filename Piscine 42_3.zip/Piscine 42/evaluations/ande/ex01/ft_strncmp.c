/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/28 18:26:49 by ande-and          #+#    #+#             */
/*   Updated: 2025/05/07 12:00:24 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while ((s1[i] == s2[i]) && (i < n))
	{
		if (s1[i] == '\0')
		{
			return (0);
		}
		i++;
	}
	if (i == n)
		return (0);
	return (s1[i] - s2[i]);
}
#include <stdio.h>
int main(void)
{
	char s1[] = "frase 2 de efeito aqui";
	char s2[] = "frase de efeito aqui";

	printf("%d\n", ft_strncmp(s1, s2, 8));

	return (0);
}