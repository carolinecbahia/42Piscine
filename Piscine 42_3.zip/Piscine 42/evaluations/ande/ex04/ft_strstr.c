/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/28 18:25:15 by ande-and          #+#    #+#             */
/*   Updated: 2025/05/07 12:02:58 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	int				size;

	i = 0;
	size = 0;
	while (dest[size] != '\0')
	{
		size++;
	}
	while ((src[i] != '\0') && (i < nb))
	{
		dest[size + i] = src[i];
		i++;
	}
	dest[size + i] = '\0';
	return (dest);
}

#include <stdio.h>

int main() {
    char str[] = "hello world, goodbye world";
    char find[] = "";
    char *result = ft_strstr(str, find);

    if (result)
        printf("Found: %s\n", result);
    else
        printf("Not found\n");

    return 0;
}