/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abarbeir <abarbeir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 13:15:09 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 15:33:21 by abarbeir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ft(int *nbr)
{
	*nbr = 42;
}

// int	main(void)
// {
// 	int	x;
//
// 	x = 0;
// 	ft_ft(&x);
// 	char dezena;
// 	char unidade;
//
// 	dezena = (x / 10) + '0';
// 	unidade = (x % 10) + '0';
// 	write(1, &dezena, 1);
// 	write(1, &unidade, 1);
// 	write(1, "\n", 1);
// 	return (0);
// }
