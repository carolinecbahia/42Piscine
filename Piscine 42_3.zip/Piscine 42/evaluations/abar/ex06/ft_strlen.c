/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ccavalca <ccavalca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 14:50:53 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 18:53:34 by ccavalca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	i++;
	return (i);
}

int main(void)
{
	char	*str;
	str = "Marcio";
	ft_strlen(str);

	int tamanho;

	tamanho = ft_strlen(str);

	char c;

	c = tamanho +'0';
	write(1, &c, 1);
	return 0;	
}
