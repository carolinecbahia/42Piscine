/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abarbeir <abarbeir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 17:14:34 by abarbeir          #+#    #+#             */
/*   Updated: 2025/05/03 15:34:56 by abarbeir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

// int main(void)
// {
// 	int x;
// 	int y;
//
// 	x = 4;
// 	y = 2;
// 	char uni1;
// 	char uni2;						
// 	uni1 = x +'0';
// 	uni2 = y +'0';
// 	ft_swap(&y, &x);
//
// 	write(1, &uni1, 1);
// 	write(1, &uni2, 1);
// 	write(1, "\n", 1);
// 	return 0;

// }
